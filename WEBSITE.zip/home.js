function myfunction()
{
    var list=document.getElementById('link');
    if(link.style.display=='block')
    {
        link.style.display="none";
    }
    else
    {
        link.style.display="block";
    }
}

